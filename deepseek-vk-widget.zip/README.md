# DeepSeek VK Widget

Простой виджет-чат для сообщества VK, использующий серверless-функцию на Vercel как прокси к DeepSeek API.
